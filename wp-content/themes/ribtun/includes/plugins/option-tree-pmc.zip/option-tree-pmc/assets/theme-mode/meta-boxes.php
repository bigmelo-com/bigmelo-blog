<?php
/**
 * Initialize the ribtun Meta Boxes. 
 */
add_action( 'admin_init', 'ribtun_meta_boxes' );

/**
 * Meta Boxes ribtun code.
 *
 * You can find all the available option types in ribtun-theme-options.php.
 *
 * @return    void
 * @since     2.0
 */
function ribtun_meta_boxes() {
  
  /**
   * Create a ribtun meta boxes array that we pass to 
   * the OptionTree Meta Box API Class.
   */
  $recipe = $recipe_hover = $crypto_options_bottom_bar_post_page = array();
  if(class_exists('WPRM_Recipe_Manager')){
	$recipe =       array(
        'label'       => esc_html__( 'Set the post as recipe post.', 'ribtun' ),
        'id'          => 'ribtun_sigle_option_recipe',
        'type'        => 'on-off',
        'desc'        => esc_html__('If set to ON this post will have different text for continue reading, comments', 'ribtun'),
        'std'         => ''
      );
	 $recipe_hover = array(
        'label'       => esc_html__( 'Show recipe on image hover(default category layout only).', 'ribtun' ),
        'id'          => 'ribtun_sigle_option_recipe_hover',
        'type'        => 'on-off',
        'desc'        => esc_html__('If set to ON recipe will show on mouse hover over the image on category view.', 'ribtun'),
        'std'         => '',
        'condition'   => 'ribtun_sigle_option_recipe:is(1)',
        'operator'    => 'and',			
      );
  }
  if(CRYPTO){	
    $crypto_options_bottom_bar_post_page =       array(
        'id'          => 'show_crypto_slider_bottom_bar_post_page',
        'label'       => 'Show Crypto slider in bottom bar for this page only.',
        'desc'        => 'Set this to on if you wish to display crypto slider inside bottom bar (this is fixed position).',
        'std'         => '',
        'type'        => 'on-off',
        'section'     => 'crypto',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      );	 
  }
  $ribtun_meta_box_post = array(
    'id'          => 'ribtun_meta_box',
    'title'       => esc_html__( 'Ribtun Options', 'ribtun' ),
    'desc'        => '',
    'pages'       => array( 'post' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
      array(
        'label'       => esc_html__( 'Ribtun post options', 'ribtun' ),
        'id'          => 'ribtun_post_options',
        'type'        => 'tab'
      ),
	  $crypto_options_bottom_bar_post_page,
      $recipe ,
	  $recipe_hover,
      array(
        'label'       => esc_html__( 'Set the fullwidth layout for this post.', 'ribtun' ),
        'id'          => 'ribtun_sigle_option_fullwidth',
        'type'        => 'on-off',
        'desc'        => esc_html__('If set to ON this post will have the fullwidth layout.','ribtun'),
        'std'         => ''
      ),
      array(
        'label'       => esc_html__( 'Use different sidebar for the single post?', 'ribtun' ),
        'id'          => 'ribtun_sigle_option_sidebar',
        'type'        => 'on-off',
        'desc'        => esc_html__('If set to ON this post will use different sidebar ("Sidebar for single blog posts").','ribtun'),
        'std'         => '',
        'condition'   => 'ribtun_sigle_option_fullwidth:is()',
        'operator'    => 'and',				
		),
      array(
        'label'       => esc_html__( 'Use Revolution slider instead of thr featured image?', 'ribtun' ),
        'id'          => 'ribtun_sigle_option_revslider',
        'type'        => 'on-off',
        'desc'        => esc_html__('If set to ON this post will use Revolution Slider instead of the feautured image.','ribtun'),
        'std'         => '',	
      ),
      array(
        'label'       => esc_html__( 'Use Revolution slider instead of featured image?', 'ribtun' ),
        'id'          => 'ribtun_sigle_option_revslider_alias',
        'type'        => 'revslider_select',
        'desc'        => esc_html__('If set to ON this you will use Revolution Slider instead of the feautured image.','ribtun'),
        'std'         => '',	
        'condition'   => 'ribtun_sigle_option_revslider:is(1)',
        'operator'    => 'and',				
      ),	  
    )
  );
  
  $ribtun_meta_box_page = array(
    'id'          => 'ribtun_meta_box',
    'title'       => esc_html__( 'Ribtun Options', 'ribtun' ),
    'desc'        => '',
    'pages'       => array( 'page' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
      array(
        'label'       => esc_html__( 'Ribtun page options', 'ribtun' ),
        'id'          => 'ribtun_pafe_options',
        'type'        => 'tab'
      ),
	  $crypto_options_bottom_bar_post_page,
      array(
        'label'       => esc_html__( 'Use Revolution slider instead of featured image?', 'ribtun' ),
        'id'          => 'ribtun_sigle_option_revslider',
        'type'        => 'on-off',
        'desc'        => esc_html__('If set to ON this page will use Revolution Slider instead of feautured image.','ribtun'),
        'std'         => '',	
      ),
      array(
        'label'       => esc_html__( 'Use Revolution slider instead of featured image?', 'ribtun' ),
        'id'          => 'ribtun_sigle_option_revslider_alias',
        'type'        => 'revslider_select',
        'desc'        => esc_html__('If set to ON this pyou will use Revolution Slider instead of feautured image.','ribtun'),
        'std'         => '',	
        'condition'   => 'ribtun_sigle_option_revslider:is(1)',
        'operator'    => 'and',				
      ),	  
    )
  );  
  
  /**
   * Register our meta boxes using the 
   * ot_register_meta_box() function.
   */
  if ( function_exists( 'ot_register_meta_box' ) ){
    ot_register_meta_box( $ribtun_meta_box_post );
	ot_register_meta_box( $ribtun_meta_box_page );
	}

}